# Frontend LeoBrick

Frontend statico pronto per Aruba.

## Dove impostare il link del server Proxmox
Apri `config.js` e sostituisci:

```js
window.LEOBRICK_API_BASE = 'https://api.tuodominio.it';
```

con il tuo dominio o IP pubblico, per esempio:

```js
window.LEOBRICK_API_BASE = 'https://api.leobrick.com';
```

## Endpoint configurabili
Sempre in `config.js` puoi cambiare i percorsi delle API:

```js
window.LEOBRICK_API_PATHS = {
  preview: '/api/preview',
  prepare: '/api/prepare-package',
  redeem: '/api/redeem'
};
```

## Nuovo flusso implementato
1. L'utente carica l'immagine.
2. L'utente modifica i parametri e clicca **Aggiorna anteprima**.
3. Il frontend chiama il backend per ottenere la preview del mosaico.
4. Quando la preview è soddisfacente, l'utente clicca **Genera istruzioni e lista componenti**.
5. Il backend prepara il pacchetto finale, lo conserva e restituisce un codice seriale.
6. L'utente comunica il codice al team LeoBrick.
7. In seguito inserisce il codice nella sezione di riscatto e scarica lo ZIP.

## API richieste dal frontend
- `POST /api/preview`
  - input: multipart/form-data con `file` e tutti i parametri del form
  - output atteso: JSON con almeno uno tra `preview_url`, `preview_image_url`, `image_url`, `preview_base64`, `image_base64`
  - campi opzionali utili: `width`, `height`, `piece_type`, `palette_size`, `preview_id`, `job_id`, `message`

- `POST /api/prepare-package`
  - input: multipart/form-data con `file` e tutti i parametri del form
  - se disponibile, il frontend invia anche `preview_id` o `preview_job_id`
  - output atteso: JSON con almeno uno tra `serial_code`, `code`, `reservation_code`, `package_code`
  - campi opzionali utili: `message`, `details`, `summary`

- `POST /api/redeem`
  - input: JSON `{ "code": "..." }`
  - output atteso: JSON con `download_url`
  - campi opzionali utili: `message`, `details`, `summary`

## File da caricare su Aruba
Carica **tutto il contenuto** di questa cartella sul tuo spazio web:
- `index.html`
- `style.css`
- `app.js`
- `config.js`
- `assets/logo.png`
