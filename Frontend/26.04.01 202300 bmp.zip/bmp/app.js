const apiBase = (window.LEOBRICK_API_BASE || '').replace(/\/$/, '');
const apiPaths = window.LEOBRICK_API_PATHS || {};
const previewEndpoint = apiPaths.preview || '/api/preview';
const prepareEndpoint = apiPaths.prepare || '/api/prepare-package';
const redeemEndpoint = apiPaths.redeem || '/api/redeem';

const fileInput = document.getElementById('fileInput');
const dropzone = document.getElementById('dropzone');
const previewCard = document.getElementById('previewCard');
const previewImage = document.getElementById('previewImage');
const previewName = document.getElementById('previewName');
const removeImageButton = document.getElementById('removeImage');
const generatorForm = document.getElementById('generatorForm');
const previewButton = document.getElementById('previewButton');
const prepareButton = document.getElementById('prepareButton');
const prepareInlineButton = document.getElementById('prepareInlineButton');
const statusText = document.getElementById('statusText');
const progressWrap = document.getElementById('progressWrap');
const progressBar = document.getElementById('progressBar');
const previewResultPanel = document.getElementById('previewResultPanel');
const generatedPreviewFrame = document.getElementById('generatedPreviewFrame');
const generatedPreviewImage = document.getElementById('generatedPreviewImage');
const resultMeta = document.getElementById('resultMeta');
const resultPreviewText = document.getElementById('resultPreviewText');
const reservationPanel = document.getElementById('reservationPanel');
const reservationMeta = document.getElementById('reservationMeta');
const reservationCode = document.getElementById('reservationCode');
const reservationNote = document.getElementById('reservationNote');
const reservationDetails = document.getElementById('reservationDetails');
const redeemForm = document.getElementById('redeemForm');
const redeemCodeInput = document.getElementById('redeemCodeInput');
const redeemButton = document.getElementById('redeemButton');
const redeemStatusText = document.getElementById('redeemStatusText');
const redeemResultPanel = document.getElementById('redeemResultPanel');
const downloadButton = document.getElementById('downloadButton');
const redeemMeta = document.getElementById('redeemMeta');
const redeemPreviewText = document.getElementById('redeemPreviewText');
const menuButton = document.getElementById('menuButton');
const mobileMenu = document.getElementById('mobileMenu');
const uploadBadge = document.getElementById('uploadBadge');

let currentFile = null;
let progressTimer = null;
let previewObjectUrl = null;
let latestPreviewPayload = null;
let latestReservationPayload = null;

function initHeroPixels() {
  const grid = document.querySelector('.pixel-grid');
  if (!grid) return;

  const palette = ['#ed1c24', '#ff7a00', '#f2b705', '#4385f5', '#c8b889', '#111827', '#e5e7eb'];
  const cells = 16 * 13;
  const fragment = document.createDocumentFragment();

  for (let i = 0; i < cells; i += 1) {
    const px = document.createElement('span');
    const color = palette[Math.floor(Math.random() * palette.length)];
    px.style.background = color;
    px.style.animationDelay = `${(i % 10) * 0.12}s`;
    fragment.appendChild(px);
  }

  grid.appendChild(fragment);
}

function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });

  document.querySelectorAll('.reveal').forEach((node) => observer.observe(node));
}

function setStatus(message) {
  statusText.textContent = message;
}

function setRedeemStatus(message) {
  redeemStatusText.textContent = message;
}

function updateSubmitState() {
  const hasFile = Boolean(currentFile);
  const hasPreview = Boolean(latestPreviewPayload);

  previewButton.disabled = !hasFile;
  prepareButton.disabled = !hasPreview;
  prepareInlineButton.disabled = !hasPreview;
  uploadBadge.textContent = hasFile ? 'File pronto' : 'Nessun file';
  uploadBadge.classList.toggle('is-ready', hasFile);
}

function setButtonLoading(button, isLoading, idleLabel, busyLabel) {
  if (!button) return;
  const label = button.querySelector('.button-label');
  button.classList.toggle('is-loading', isLoading);
  button.disabled = isLoading || button.disabled;
  if (label) label.textContent = isLoading ? busyLabel : idleLabel;
}

function setPreviewLoading(isLoading) {
  previewButton.classList.toggle('is-loading', isLoading);
  const label = previewButton.querySelector('.button-label');
  if (label) label.textContent = isLoading ? 'Anteprima in corso' : 'Aggiorna anteprima';
  previewButton.disabled = isLoading || !currentFile;
  prepareButton.disabled = isLoading || !latestPreviewPayload;
  prepareInlineButton.disabled = isLoading || !latestPreviewPayload;
}

function setPrepareLoading(isLoading) {
  [prepareButton, prepareInlineButton].forEach((button) => {
    button.classList.toggle('is-loading', isLoading);
    const label = button.querySelector('.button-label');
    if (label) {
      label.textContent = isLoading ? 'Preparazione in corso' : 'Genera istruzioni e lista componenti';
    }
  });
  prepareButton.disabled = isLoading || !latestPreviewPayload;
  prepareInlineButton.disabled = isLoading || !latestPreviewPayload;
  previewButton.disabled = isLoading || !currentFile;
}

function setRedeemLoading(isLoading) {
  redeemButton.classList.toggle('is-loading', isLoading);
  const label = redeemButton.querySelector('.button-label');
  if (label) label.textContent = isLoading ? 'Verifica in corso' : 'Scarica pacchetto finale';
  redeemButton.disabled = isLoading;
}

function validateFile(file) {
  if (!file) return 'Nessun file selezionato.';
  if (!file.type.startsWith('image/')) return 'Carica un file immagine valido.';
  if (file.size > 15 * 1024 * 1024) return 'Il file supera 15 MB.';
  return null;
}

function startFakeProgress() {
  progressWrap.hidden = false;
  let value = 6;
  progressBar.style.width = `${value}%`;
  clearInterval(progressTimer);

  progressTimer = setInterval(() => {
    value = Math.min(value + Math.random() * 11, 92);
    progressBar.style.width = `${value}%`;
  }, 260);
}

function stopFakeProgress(done = true) {
  clearInterval(progressTimer);
  progressTimer = null;
  progressBar.style.width = done ? '100%' : '0%';

  setTimeout(() => {
    progressWrap.hidden = true;
    if (!done) progressBar.style.width = '0%';
  }, 450);
}

function resetGeneratedState() {
  latestPreviewPayload = null;
  latestReservationPayload = null;
  previewResultPanel.hidden = true;
  reservationPanel.hidden = true;
  redeemResultPanel.hidden = true;
  generatedPreviewFrame.hidden = true;
  generatedPreviewImage.removeAttribute('src');
  resultMeta.textContent = 'Dimensioni, palette e dettagli appariranno qui dopo la preview.';
  resultPreviewText.textContent = 'L’anteprima generata dal backend sarà mostrata qui.';
  reservationCode.textContent = '—';
  reservationMeta.textContent = 'Il backend ha preparato istruzioni e lista componenti per questa configurazione.';
  reservationNote.textContent = 'Conserva questo codice: servirà per riscattare il pacchetto finale.';
  reservationDetails.textContent = 'Quando il team LeoBrick ti confermerà il codice, potrai inserirlo nella sezione qui sotto per scaricare il pacchetto.';
  downloadButton.href = '#';
  redeemMeta.textContent = 'Il backend ha verificato il codice e rilasciato il pacchetto salvato.';
  redeemPreviewText.textContent = 'Dopo la verifica del codice troverai qui i dettagli del pacchetto.';
  updateSubmitState();
}

function setPreview(file) {
  currentFile = file;
  resetGeneratedState();

  if (previewObjectUrl) URL.revokeObjectURL(previewObjectUrl);

  previewObjectUrl = URL.createObjectURL(file);
  previewImage.src = previewObjectUrl;
  previewName.textContent = file.name;
  previewCard.hidden = false;
  dropzone.classList.add('has-file');
  setStatus(`${file.name} selezionato. Ora puoi generare l’anteprima.`);
  updateSubmitState();
}

function resetPreview() {
  currentFile = null;
  fileInput.value = '';
  previewImage.removeAttribute('src');
  previewName.textContent = 'Immagine pronta';
  previewCard.hidden = true;
  dropzone.classList.remove('has-file', 'dragover');

  if (previewObjectUrl) {
    URL.revokeObjectURL(previewObjectUrl);
    previewObjectUrl = null;
  }

  resetGeneratedState();
  setStatus('Carica un’immagine per iniziare.');
  updateSubmitState();
}

function handleIncomingFile(file, syncInput = false) {
  const error = validateFile(file);
  if (error) {
    setStatus(error);
    return;
  }

  if (syncInput && file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;
  }

  setPreview(file);
}

function buildGenerationFormData() {
  const formData = new FormData();
  const formValues = new FormData(generatorForm);

  if (currentFile) formData.append('file', currentFile);

  for (const [key, value] of formValues.entries()) {
    if (key === 'dither' || key === 'generate_pdf' || key === 'generate_stud_preview' || key === 'piece_aware_palette') {
      formData.append(key, 'on');
    } else {
      formData.append(key, value);
    }
  }

  ['dither', 'generate_pdf', 'generate_stud_preview', 'piece_aware_palette'].forEach((key) => {
    if (!formValues.has(key)) formData.append(key, 'off');
  });

  if (latestPreviewPayload?.preview_id) formData.append('preview_id', latestPreviewPayload.preview_id);
  if (latestPreviewPayload?.job_id) formData.append('preview_job_id', latestPreviewPayload.job_id);

  return formData;
}

function getPreviewImageSource(payload) {
  if (!payload) return '';
  if (payload.preview_url) return payload.preview_url;
  if (payload.image_url) return payload.image_url;
  if (payload.preview_image_url) return payload.preview_image_url;
  if (payload.preview_base64) return `data:image/png;base64,${payload.preview_base64}`;
  if (payload.image_base64) return `data:image/png;base64,${payload.image_base64}`;
  return '';
}

function summarizeGeneration(payload) {
  const width = payload.width || payload.output_width || '—';
  const height = payload.height || payload.output_height || '—';
  const pieceType = payload.piece_type || payload.pieceType || 'pezzo non specificato';
  const paletteSize = payload.palette_size || payload.max_colors || payload.colors_count || '—';
  return `Dimensione finale ${width}×${height} — ${pieceType} — ${paletteSize} colori.`;
}

function showPreviewResult(payload) {
  const previewSrc = getPreviewImageSource(payload);
  resultMeta.textContent = summarizeGeneration(payload);
  resultPreviewText.textContent = payload.message || 'Anteprima aggiornata. Puoi continuare a modificare i parametri o generare il pacchetto finale.';

  if (previewSrc) {
    generatedPreviewImage.src = previewSrc;
    generatedPreviewFrame.hidden = false;
  } else {
    generatedPreviewFrame.hidden = true;
  }

  previewResultPanel.hidden = false;
}

function showReservationResult(payload) {
  const code = payload.serial_code || payload.code || payload.reservation_code || payload.package_code || '—';
  reservationCode.textContent = code;
  reservationMeta.textContent = payload.message || 'Comunica questo codice al team LeoBrick e procedi con PayPal.';
  reservationNote.textContent = 'Comunica questo codice al team LeoBrick e procedi con PayPal.';
  reservationDetails.textContent = payload.details || payload.summary || 'Il pacchetto è stato preparato e conservato dal backend. Dopo la conferma del team potrai riscattarlo con questo codice.';
  reservationPanel.hidden = false;

  if (code && code !== '—') {
    redeemCodeInput.value = code;
  }
}

function showRedeemResult(payload) {
  const url = payload.download_url || payload.url;
  if (!url) throw new Error('Il backend non ha restituito il link di download.');

  downloadButton.href = url;
  redeemMeta.textContent = payload.message || 'Codice verificato con successo.';
  redeemPreviewText.textContent = payload.details || payload.summary || 'Download pronto. Usa il pulsante per scaricare il pacchetto finale.';
  redeemResultPanel.hidden = false;
}

async function postForm(endpoint, formData) {
  const response = await fetch(`${apiBase}${endpoint}`, {
    method: 'POST',
    body: formData,
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.detail || payload.message || `Errore API (${response.status})`);
  }

  return payload;
}

async function postJson(endpoint, body) {
  const response = await fetch(`${apiBase}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.detail || payload.message || `Errore API (${response.status})`);
  }

  return payload;
}

fileInput.addEventListener('change', (event) => {
  const file = event.target.files?.[0];
  handleIncomingFile(file);
});

['dragenter', 'dragover'].forEach((eventName) => {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.add('dragover');
  });
});

['dragleave', 'drop'].forEach((eventName) => {
  dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropzone.classList.remove('dragover');
  });
});

dropzone.addEventListener('drop', (event) => {
  const file = event.dataTransfer?.files?.[0];
  handleIncomingFile(file, true);
});

removeImageButton.addEventListener('click', resetPreview);

menuButton.addEventListener('click', () => {
  const expanded = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!expanded));
  mobileMenu.classList.toggle('open');
});

mobileMenu.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    mobileMenu.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  });
});

generatorForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  if (!apiBase || apiBase.includes('tuodominio.it')) {
    setStatus('Servizio temporaneamente non disponibile. Configura il backend in config.js.');
    return;
  }

  const error = validateFile(currentFile);
  if (error) {
    setStatus(error);
    return;
  }

  setPreviewLoading(true);
  setStatus('Generazione anteprima in corso...');
  previewResultPanel.hidden = true;
  reservationPanel.hidden = true;
  startFakeProgress();

  try {
    const payload = await postForm(previewEndpoint, buildGenerationFormData());
    latestPreviewPayload = payload;
    latestReservationPayload = null;
    stopFakeProgress(true);
    setPreviewLoading(false);
    setStatus('Anteprima aggiornata. Controlla il risultato oppure genera il pacchetto finale.');
    showPreviewResult(payload);
    previewResultPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    updateSubmitState();
  } catch (errorObj) {
    stopFakeProgress(false);
    setPreviewLoading(false);
    setStatus(errorObj.message || 'Errore imprevisto durante la preview.');
    updateSubmitState();
  }
});

async function handlePreparePackage() {
  if (!apiBase || apiBase.includes('tuodominio.it')) {
    setStatus('Servizio temporaneamente non disponibile. Configura il backend in config.js.');
    return;
  }

  if (!latestPreviewPayload) {
    setStatus('Genera prima un’anteprima valida.');
    return;
  }

  setPrepareLoading(true);
  setStatus('Preparazione di istruzioni e lista componenti in corso...');
  reservationPanel.hidden = true;
  startFakeProgress();

  try {
    const payload = await postForm(prepareEndpoint, buildGenerationFormData());
    latestReservationPayload = payload;
    stopFakeProgress(true);
    setPrepareLoading(false);
    setStatus('Codice generato con successo. Comunicalo al team LeoBrick.');
    showReservationResult(payload);
    reservationPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    updateSubmitState();
  } catch (errorObj) {
    stopFakeProgress(false);
    setPrepareLoading(false);
    setStatus(errorObj.message || 'Errore imprevisto durante la preparazione del pacchetto.');
    updateSubmitState();
  }
}

prepareButton.addEventListener('click', handlePreparePackage);
prepareInlineButton.addEventListener('click', handlePreparePackage);

redeemForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  if (!apiBase || apiBase.includes('tuodominio.it')) {
    setRedeemStatus('Servizio temporaneamente non disponibile. Configura il backend in config.js.');
    return;
  }

  const code = redeemCodeInput.value.trim();
  if (!code) {
    setRedeemStatus('Inserisci un codice valido.');
    return;
  }

  setRedeemLoading(true);
  setRedeemStatus('Verifica del codice in corso...');
  redeemResultPanel.hidden = true;

  try {
    const payload = await postJson(redeemEndpoint, { code });
    setRedeemLoading(false);
    setRedeemStatus('Codice verificato. Puoi scaricare il pacchetto finale.');
    showRedeemResult(payload);
    redeemResultPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (errorObj) {
    setRedeemLoading(false);
    setRedeemStatus(errorObj.message || 'Errore imprevisto durante il riscatto del codice.');
  }
});

document.querySelectorAll('.magnetic').forEach((button) => {
  button.addEventListener('mousemove', (event) => {
    if (button.disabled) return;
    const rect = button.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width - 0.5) * 12;
    const y = ((event.clientY - rect.top) / rect.height - 0.5) * 12;
    button.style.transform = `translate(${x}px, ${y}px)`;
  });

  button.addEventListener('mouseleave', () => {
    button.style.transform = 'translate(0, 0)';
  });
});

updateSubmitState();
initHeroPixels();
initReveal();
