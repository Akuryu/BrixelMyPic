window.LEOBRICK_API_BASE = 'https://api.tuodominio.it';

window.LEOBRICK_API_PATHS = {
  preview: '/api/preview',
  prepare: '/api/prepare-package',
  redeem: '/api/redeem'
};
