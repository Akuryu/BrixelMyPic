const apiBase = (window.LEOBRICK_API_BASE || '').replace(/\/$/, '');

const fileInput = document.getElementById('fileInput');
const previewButton = document.getElementById('previewButton');
const generateButton = document.getElementById('generateButton');

const previewImage = document.getElementById('previewImage');
const statusText = document.getElementById('statusText');

const codeBox = document.getElementById('codeBox');
const paypalSection = document.getElementById('paypalSection');

const redeemInput = document.getElementById('redeemInput');
const redeemButton = document.getElementById('redeemButton');

let currentFile = null;
let generatedCode = null;

/* ---------------- FILE ---------------- */

fileInput.addEventListener('change', (e) => {
  currentFile = e.target.files[0];
});

/* ---------------- PREVIEW ---------------- */

previewButton.addEventListener('click', async () => {
  if (!currentFile) return;

  const formData = new FormData();
  formData.append('file', currentFile);

  const res = await fetch(`${apiBase}/api/preview`, {
    method: 'POST',
    body: formData
  });

  const blob = await res.blob();
  previewImage.src = URL.createObjectURL(blob);
});

/* ---------------- GENERATE ---------------- */

generateButton.addEventListener('click', async () => {
  if (!currentFile) return;

  const formData = new FormData();
  formData.append('file', currentFile);

  const res = await fetch(`${apiBase}/api/prepare-package`, {
    method: 'POST',
    body: formData
  });

  const data = await res.json();
  generatedCode = data.code;

  codeBox.innerText = generatedCode;
  codeBox.style.display = 'block';
  paypalSection.style.display = 'block';
});

/* ---------------- PAYPAL ---------------- */

window.initPayPal = function() {
  paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: { value: '5.00' }
        }]
      });
    },
    onApprove: async function(data, actions) {
      await actions.order.capture();

      const res = await fetch(`${apiBase}/api/confirm-payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: generatedCode })
      });

      const result = await res.json();
      alert("Redeem token: " + result.redeem_token);
    }
  }).render('#paypalButtonContainer');
}

/* ---------------- REDEEM ---------------- */

redeemButton.addEventListener('click', async () => {
  const value = redeemInput.value;

  if (value.startsWith('LEO-')) {
    alert("Completa il pagamento prima");
    return;
  }

  if (!value.startsWith('RDM-')) {
    alert("Codice non valido");
    return;
  }

  const res = await fetch(`${apiBase}/api/redeem`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: value })
  });

  const blob = await res.blob();
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = 'package.zip';
  a.click();
};
