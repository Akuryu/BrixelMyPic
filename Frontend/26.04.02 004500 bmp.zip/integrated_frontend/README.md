# LeoBrick Frontend

Frontend invariato nei parametri e nel payload inviato al backend.

## Endpoint usati
- `POST /api/generate` con `multipart/form-data`

## Parametri inviati
- `file`
- `width`
- `height`
- `piece_type`
- `max_colors`
- `resize_mode`
- `panel_rounding`
- `dither`
- `generate_pdf`
- `generate_stud_preview`
- `piece_aware_palette`

`config.js` usa base URL relativa (`''`) così il frontend funziona dietro lo stesso dominio del backend.
